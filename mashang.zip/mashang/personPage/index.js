$(".navigation span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});

//点击头像显示隐藏菜单
$('.headshot img').click(function(){
    // console.log(222);
    // $('.user').css({'display':'block'});
    $('.user').toggle();
});

//点击退出登录返回登录页
$('.exit').click(function(){
    location.replace('../loginPage/index.html');
});

//我的视频
$('.myvideo').click(function(){
    location.assign('../myVideoPage/myClassAll/index.html')
})


//获取用户头像
function getUserInfo() {    
    // console.log(res.img);
    getUserApi({}, function (res) {
        $('.headshot img').prop('src',BASE_URL+res.data.avatar);
        console.log(res);
        var infoChild =  `
        <div class="person_img"><img src="${BASE_URL + res.data.avatar}"></div>
                <div class="change_headshot">修改头像</div>
                <div class="text">姓名：<span>${res.data.nickName}</span></div>
                <div class="text">年级：<span>${res.data.grade}</span></div>
                <div class="text">方向：<span>${res.data.major}</span></div>
                <div class="text">班级：<span>${res.data.classes[0].className}${res.data.classes[1].className}</span></div>
                <div class="text">任课老师：<span>${res.data.classes[0].headmaster.nickName}</span></div>
                <div class="text">教务老师：<span>${res.data.guide}</span></div>
        `;
        $('.information').append(infoChild);   
    });
}

//首页
$('.home').click(function(){
    location.assign("../homePage/index.html");
});
$('.navigation span').eq(0).click(function(){
    location.assign("../homePage/index.html");
})

//页面加载
$(function(){
    getUserInfo();       
    $(".navigation span").eq(2).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"      
    });
});
