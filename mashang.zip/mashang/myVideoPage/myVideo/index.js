$(".navigation span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});
$(".box2 span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"2px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});
//---------------------个人中心
$('.person').click(function(){
    location.assign('../../personPage/index.html')
})

//---------------------点击头像显示隐藏菜单
$('.headshot img').click(function(){
    // console.log(222);
    // $('.user').css({'display':'block'});
    $('.user').toggle();
});

//---------------------点击退出登录返回登录页
$('.exit').click(function(){
    location.replace('../../loginPage/index.html');
});

//---------------------我的视频
$('.myvideo').click(function(){
    location.assign('../myClassAll/index.html')
})
//---------------------获取用户头像
function getUserInfo() {    
    // console.log(res.img);
    getUserApi({}, function (res) {
        $('.headshot img').prop('src',BASE_URL+res.data.avatar);
    });
}

//---------------------获取视频详情数据
function getDetail(){
    //---------------------视频图片+班级名称
    getClassApi({},function(res){        
        $.each(res.rows,function(index,item){
            if(item.classId==location.search.substring(1)){
                $('.video_list_img img').prop('src',BASE_URL+item.classCover);
                $('.video_list_class span').html(`${item.className}`)
            }
        });        
    });
    //---------------------视频+播放列表
    getVideo(location.search.substring(1),function(res){
        // var FileSaver = require('file-saver');
        console.log(res);
        var Num = 1;
        $.each(res.rows,function(index,item){
            var num = 1;
            var videoChild = `<div class="video_list_chapterName">HTML</div><div class="catalogues">${res.rows[Num-1].catalogues.length}节</div>`;
            $('.video_box').append(videoChild);
            $.each(item.catalogues,function(index1,temp) {
                var ctlgChild = `
                <div class="catalogue" tile="${temp.playUrl}" 
                coursewareUrl="${temp.coursewareUrl}"
                coursewareName="${temp.coursewareName}">
                <span class="row-box">
                    <div class="row">${Num}-${num}</div>
                    <div class="catalogueName">${temp.catalogueName}</div>
                </span>
                    <div class="video_times"></div>
                    <div class="teacher">ABC</div>
                    <div style="color: #9199A1;
                        display: inline-block;
                        font-size: 12px;">|</div>
                    <div class="playback">13次播放</div>
                    <div id="task" style="display: none;">${temp.task}</div>
                    </div>
                    
                `;   
                 $('.video_box').append(ctlgChild);
                $('.homework_text').append(temp.task);
                num++;
            }); 
            
            $('.catalogue').eq(index).click(function(){            
                var cata = $(this);
                $('.video_play video').prop('src',BASE_URL+$(this).attr("tile"));     
                $('.homework').unbind(); //清除绑定事件
                $('.homework').click(function(){
                    console.log(222);
                    courseDownload(BASE_URL+cata.attr("coursewareUrl"), cata.attr("coursewareName"));
                });
                $('.work').unbind(); //清除绑定事件
                $('.work').click(function(){
                    $('.homework_text').html("");
                    $('.homework_text').html(cata.find("#task").html());                
                    $('.homework_text').css('display','block');
                    $('.homework').css('display','none');
                    $(this).css({
                        "color":"#FF6000",
                        "border-bottom":"2px solid #FF6000"
                    });
                    $(this).siblings().css({
                        "color":"black",
                        "border-bottom":"0px solid #FF6000"
                    });
                })
                $(this).css({               
                    "background-color":"#161A23"               
                });
                $(this).siblings().css({               
                    "background-color":"#1C202C"   
                });
                $(this).find('.row-box').css({               
                    "color":"#FF6000"               
                });
                $(this).siblings().find('.row-box').css({               
                    "color":"#fff"   
                });
                $(".box2 span").eq(0).click();
                //console.log($(this));
                var sb = $(this).siblings()
                $(".video_play video")[0].addEventListener("loadedmetadata", function() {
                    var tol = this.duration; //获取总时长
                     s = Math.floor(tol)%60
                     m = (Math.floor(tol)-s)/60
                     h = (Math.floor(tol)-s-m*60)/3600
                    cata.children('.video_times').text(h+':'+m+':'+s);
                    cata.siblings().children('.video_times').text("");
                });

            })
            
            Num++;            
        });
        //---------------------点击事件
        
    });
}
//---------------------课件点击
$(".box2 span").eq(0).click(function(){
    $('.homework_text').css('display','none');
    $('.homework').css('display','block');  
    $(this).css({
        "color":"orangered",
        "border-bottom":"2px solid orangered"        
    });  
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    }); 
});
//---------------------作业点击
$('.work').click(function(){
    $('.homework_text').css('display','block');
    $('.homework_text').html("");
    $('.homework').css('display','none');
})
//---------------------首页
$('.home').click(function(){
    location.assign("../../homePage/index.html")
});
//---------------------活动展示页
$('.activities').click(function(){
    location.assign("../activitiesAll/index.html")
});

//---------------------页面加载
$(function(){
    getUserInfo();   
    getDetail();
    $(".navigation span").eq(1).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"      
    });    
    $(".box2 span").eq(0).click();
    $('.catalogue').eq(0).click();
});

  /* ---------------------下载
   @param  {String} url ---------------------目标文件地址
   @param  {String} filename ---------------------想要保存的文件名称*/
  function courseDownload(url, filename) {
    getBlob(url, function(blob) {
      saveAs(blob, filename);
    })
  }
  function getBlob(url,cb) {
    let xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'blob';
    xhr.onload = function() {
      if (xhr.status === 200) {
        cb(xhr.response);
      }
    }
    xhr.send();
  }
  /* ---------------------保存
   @param  {Blob} blob
   @param  {String} filename ---------------------想要保存的文件名称*/
  function saveAs(blob, filename) {
    if (window.navigator.msSaveOrOpenBlob) {
      navigator.msSaveBlob(blob, filename);
    } else {
      let link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(link.href);
    }
  }
