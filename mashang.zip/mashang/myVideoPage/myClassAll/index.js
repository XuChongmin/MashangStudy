$(".navigation span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});

//个人中心
$('.person').click(function(){
    location.assign('../../personPage/index.html')
})
//点击头像显示隐藏菜单
$('.headshot img').click(function(){
    // console.log(222);
    // $('.user').css({'display':'block'});
    $('.user').toggle();
});

//点击退出登录返回登录页
$('.exit').click(function(){
    location.replace('../../loginPage/index.html');
});


//获取用户头像
function getUserInfo() {    
    // console.log(res.img);
    getUserApi({}, function (res) {
        $('.headshot img').prop('src',BASE_URL+res.data.avatar);
    });
}


function myClassCreate(){
    getClassApi({},function(res){
        console.log(res);
        $.each(res.rows,function(index,item){
            var cardChild =`
            <div class="myvideo">
                <div class="myvideo_img"><img src="${BASE_URL + item.classCover}"></div>
                <div class="myvideo_title">${item.className}</div>
                <div class="myvideo_content">
                    <div class="myvideo_content_box">${item.catalogueName}</div>
                </div>
                <div class="teacher">
                    <div class="teacher_logo"></div>
                    <div class="teacher_name">${item.nickName}</div>
                    <div class="chapterName">${item.chapterName}</div>
                </div>
            </div>
            `;

            $('.box').append(cardChild); 
        });
         //点击事件
        $('.myvideo').click(function(){
            console.log($(this).index());
            var clickData = res.rows[$(this).index()];           
            
            location.assign(`../myVideo/index.html?${clickData.classId}`);
        });
    });
}


//首页
$('.home').click(function(){
    location.assign("../../homePage/index.html")
});




//页面加载
$(function(){
    getUserInfo();    
    myClassCreate();
    $(".navigation span").eq(1).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"      
    });
});
