var BASE_URL="http://mashang.eicp.vip:5557/ms-elearning/api666";

/**
 * 
 * @param {*} url 地址
 * @param {*} data 参数
 * @param {*} callback 回调
 * @param {*} isToken 是否使用token
 */
function baseGet(url,data,callback,isToken = true){
    var headers = isToken ? {Authorization:"Bearer "+$.cookie("token")}:{};
    $.ajax({
        url:BASE_URL+url,
        data: data,
        type:"GET",
        headers:headers,
        contentType:"application/x-WWW-form-urlencoded",
        success:function(response){
            callback(response);
        },
        error:function(err){
            console.error(err);
        },
    });        
}

function basePOST(url,data,callback,isToken = true){
    var headers = isToken ? {Authorization:"Bearer "+$.cookie("token")}:{};
    $.ajax({
        url:BASE_URL+url,
        data: JSON.stringify(data),
        type:"POST",
        headers:headers,
        contentType:"application/json",
        success:function(response){
            callback(response);
        },
        error:function(err){
            console.error(err);
        },
    });        
}

// 验证码接口
function getCodeApi(data,callback){
    baseGet(
        "/captchaImage",
        data,
        function(res){
            callback(res);
        },
        false
    );
}

//登陆接口
function signUpApi(data,callback){
    basePOST(
        "/login",
        data,
        function(res){
            callback(res);
        },
        false
    );
}

//用户信息接口
function getUserApi(data,callback){
    baseGet(
        "/elearning/student/cur",
        data,
        function(res){
            callback(res);
        },
        true
    );
}

//获取轮播图接口
function getBannerApi(data,callback){
    baseGet(
        "/elearning/banner",
        data,
        function(res){
            callback(res);
        },
        true
    );
}

//活动展示卡片接口
function getHomeActivityApi(data,callback){
    baseGet(
        "/elearning/activity/release/list",
        data,
        function(res){
            callback(res);
        },
        true
    );    
}

//活动详情接口
function getActivityDetailApi(data,callback){
    baseGet(
        "/elearning/activity/release/"+ data,
        data,
        function(res){
            callback(res);
        }
    );
}

//知识分享卡片接口
function getKnowledgeSharingApi(data,callback){
    baseGet(
        "/elearning/knowledgeSharing/release/list",
        data,
        function(res){
            callback(res);
        },
        true
    );    
}


//活动详情接口
function getKnowledgeSharingDetailApi(data,callback){
    baseGet(
        "/elearning/knowledgeSharing/release/"+ data,
        data,
        function(res){
            callback(res);
        }
    );
}

//班级接口
function getClassApi(data,callback){
    baseGet(
        "/elearning/class/process",
        data,
        function(res){
            callback(res);
        }
        
    );
}

//视频信息接口
function getVideo(data,callback){
    baseGet(
        "/elearning/chapter/list?classId="+data,
        data,
        function(res){
            callback(res);
        }        
    );
}
