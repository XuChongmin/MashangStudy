$(".navigation span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});
//首页
$('.home').click(function(){
    location.assign('../homePage/index.html')
})

//个人中心
$('.person').click(function(){
    location.assign('../personPage/index.html')
})

//我的视频
$('.myvideo').click(function(){
    location.assign('../myVideoPage/myClassAll/index.html')
})

//点击头像显示隐藏菜单
$('.headshot img').click(function(){
    // console.log(222);
    // $('.user').css({'display':'block'});
    $('.user').toggle();
});

//点击退出登录返回登录页
$('.exit').click(function(){
    location.replace('../loginPage/index.html');
});


//获取用户头像
function getUserInfo() {    
    // console.log(res.img);
    getUserApi({}, function (res) {
        $('.headshot img').prop('src',BASE_URL+res.data.avatar);
    });
}

//创建轮播图
var bannerInfo = [];
var WIDTH;
function bannerCreate(){
    var activeIndex = 1;//公共下标
    
    getBannerApi({},function(res){
        console.log(res);
        bannerInfo =  [...res.rows];
        
        //在第一张前面放最后一张
        bannerInfo.unshift(bannerInfo[bannerInfo.length-1]);
        //最后一张前放第一张
        bannerInfo.push(bannerInfo[1]);

        //创建节点
        $.each(bannerInfo,function(index,item){
            var bgChild = `
            <div class="bg-item">
                <div class="center">
                <div class="left"><img src="../Public/img/left.png"></div>
                <div class="right"><img src="../Public/img/right.png"></div>
                </div>
            </div>            
            `
            //添加节点
            $('.bg-move').append(bgChild);
            //添加背景颜色
            $('.bg-item').eq(index).css('background-color',item.colorTone);
            //添加图片
            $('.bg-item .center').eq(index).css('background-image',`url(${BASE_URL}${item.bannerUrl})`);

            //宽度
            WIDTH = $(document).width();
            $(".bg-move").css('width',WIDTH*bannerInfo.length);
            $(".bg-item").css('width',WIDTH);                            
        });  
        //初始化位置
        $('.bg-move').css('left',-WIDTH * activeIndex +'px');

        //左按钮
        $('.banner .left').click(function(){
            activeIndex--;
            $('.bg-move').animate({'left':-WIDTH * activeIndex +'px'},
            "200ms",
            'linear',
            function(){                
                if(activeIndex==0){
                    activeIndex = bannerInfo.length-2;
                }
                $('.bg-move').css('left',-WIDTH * activeIndex +'px');
            });
        });
            
        //右按钮
        $('.banner .right').click(function(){
            activeIndex++;
            $('.bg-move').animate({'left':-WIDTH * activeIndex +'px'},
            "200ms",
            'linear',
            function(){                
                if(activeIndex==bannerInfo.length-2){
                    activeIndex = 0;
                }
                $('.bg-move').css('left',-WIDTH * activeIndex +'px');
            });
        });
        
        
    });
}

//创建活动展示卡片页
function activityCreate(){
    getHomeActivityApi({},function(res){
        
        $.each(res.rows.slice(0,8),function(index,item){
            var cardChild =`
            <div class="activity">
                <div class="activity_img"><img src="${BASE_URL + item.coverUrl}"></div>
                <div class="activity_title">${item.activityTitle}</div>
                <div class="activity_content">
                    <div class="activity_content_box">${item.activityIntroduce}</div>
                </div>
                <div class="time">
                    <div class="time_logo"></div>
                    <div class="times">${item.createTime.substr(0,10)}</div>
                </div>
            </div>
            `;

            $('.box').append(cardChild);
            
        });
        //活动展示点击事件
        $('.activity').click(function(){
            console.log($(this).index());
            var clickData = res.rows[$(this).index()];
            
            //是否外链
            location.assign(clickData.isLink == '0'?
            `../activityPage/activityDetail/index.html?${clickData.activityId}`: clickData.link)
        });
    });
}

//查看全部活动按钮
$('.activities_show_all').click(function(){
    location.assign("../activityPage/activitiesAll/index.html")
});

//创建知识分享卡片页
function knowledgeSharingCreate(){
    getKnowledgeSharingApi({},function(res){
        console.log(res.rows);
        $.each(res.rows.slice(0,8),function(index,item){
            var cardChild =`
            <div class="share">
            <div class="share_img"><img src="${BASE_URL + item.coverUrl}"></div>
            <div class="share_title">${item.sharingTitle}</div>
            <div class="share_content">
                <div class="share_content_box">${item.sharingIntroduce}</div>
            </div>
            <div class="time">
                <div class="time_logo"></div>
                <div class="times">${item.createTime.substr(0,10)}</div>
            </div>
            </div>
            `;

            $('.box2').append(cardChild);
            
        });
        //知识分享点击事件
        $('.share').click(function(){
            console.log($(this).index());
            var clickData = res.rows[$(this).index()];
            
            //是否外链
            location.assign(clickData.isLink == '0'?
            `../sharingPage/sharingDetail/index.html?${clickData.sharingId}`: clickData.link)
        });
    });
}

//查看全部活动按钮
$('.sharing_show_all').click(function(){
    location.assign("../sharingPage/sharingAll/index.html")
});


//页面加载
$(function(){
    getUserInfo();
    bannerCreate();
    activityCreate();
    knowledgeSharingCreate();
    $(".navigation span").eq(0).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"      
    });
});
