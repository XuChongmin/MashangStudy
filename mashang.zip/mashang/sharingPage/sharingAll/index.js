$(".navigation span").click(function(){
    $(this).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"
    });
    $(this).siblings().css({
        "color":"black",
        "border-bottom":"0px solid orangered"
    });
});

//个人中心
$('.person').click(function(){
    location.assign('../../personPage/index.html')
})
//点击头像显示隐藏菜单
$('.headshot img').click(function(){
    // console.log(222);
    // $('.user').css({'display':'block'});
    $('.user').toggle();
});

//点击退出登录返回登录页
$('.exit').click(function(){
    location.replace('../../loginPage/index.html');
});
//我的视频
$('.myvideo').click(function(){
    location.assign('../myVideoPage/myClassAll/index.html')
})

//获取用户头像
function getUserInfo() {    
    // console.log(res.img);
    getUserApi({}, function (res) {
        $('.headshot img').prop('src',BASE_URL+res.data.avatar);
    });
}


//创建知识分享卡片页
function knowledgeSharingCreate(){
    getKnowledgeSharingApi({},function(res){
        console.log(res.rows);
        $.each(res.rows,function(index,item){
            var cardChild =`
            <div class="share">
            <div class="share_img"><img src="${BASE_URL + item.coverUrl}"></div>
            <div class="share_title">${item.sharingTitle}</div>
            <div class="share_content">
                <div class="share_content_box">${item.sharingIntroduce}</div>
            </div>
            <div class="time">
                <div class="time_logo"></div>
                <div class="times">${item.createTime.substr(0,10)}</div>
            </div>
            </div>
            `;

            $('.box2').append(cardChild);
            
        });
        //知识分享点击事件
        $('.share').click(function(){
            console.log($(this).index());
            var clickData = res.rows[$(this).index()];
            
            //是否外链
            location.assign(clickData.isLink == '0'?
            `../../sharingPage/sharingDetail/index.html?${clickData.sharingId}`: clickData.link)
        });
    });
}



//首页
$('.home').click(function(){
    location.assign("../../homePage/index.html")
});




//页面加载
$(function(){
    getUserInfo();    
    knowledgeSharingCreate();
    $(".navigation span").eq(0).css({
        "color":"orangered",
        "border-bottom":"5px solid orangered"      
    });
});
